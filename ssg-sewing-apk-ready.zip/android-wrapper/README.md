# Android APK wrapper

This app is a server-rendered website (TanStack Start + Cloudflare Worker + D1 database for OTP/bookings),
so the APK is a Capacitor WebView that opens your **deployed** site.

1. Deploy the site and note its https URL.
2. GitHub repo > Settings > Secrets and variables > Actions > Variables > add `APP_URL` = your URL
   (or pass it when running the workflow manually).
3. Actions > "Build Android APK" > Run workflow.
4. Download the `SSG-Sewing-apk` artifact, unzip, install `SSG-Sewing.apk` on your phone.
